package com.messaging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageQueueApplicationTests {

	@Test
	void contextLoads() {
	}

}
